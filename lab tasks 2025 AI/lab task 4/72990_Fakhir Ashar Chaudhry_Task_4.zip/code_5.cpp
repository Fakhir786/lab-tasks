#include<iostream>
#include<cmath>
using namespace std;
int main()
{
    cout<<"Sap_ID: 72990"<<endl<<"Name: Fakhir Ashar Chaudhry"<<endl;
    int choice;

    cout<<"If you want to perform triginometric and exponenetial calculations (press 1) otherwise (press 2):"<<endl;    
    cin>>choice;

    switch(choice)        //Taking calculation choice from user
    {
        case 1:
            int choice_2;
            cout<<"Select an option from below:"<<endl<<"1.Sine \n2.Cosine \n3.Tangent  \n4.Square \n5.Cube \n6.Square Root"<<endl;
            cin>>choice_2;
            double num,ans;
            cout<<"Enter a number:";
            cin>>num;

            switch (choice_2)               //Solving triginometry calculations
            {   
                
                case 1:   //Sine
                    ans=sin(num);
                    cout<<"Answer = "<<ans;   
                    break;                 

                case 2:   //Cos
                    ans=cos(num);
                    cout<<"Answer = "<<ans;
                    break;

                case 3:   // Tangent
                    ans=tan(num);
                    cout<<"Answer = "<<ans;
                    break;

                case 4:   // Square
                    ans=pow(num,2);
                    cout<<"Answer = "<<ans;
                    break;

                case 5:   // Cube
                    ans=pow(num,3);
                    cout<<"Answer = "<<ans;
                    break;

                case 6:   // Square Root
                    ans=sqrt(num);
                    cout<<"Answer = "<<ans;
                    break;

                default:
                    cout<<"You entered an invalid choice";
                    break;
            }
            break;


        case 2:                
            int choice_4,choice_5,a,b;
            cout<<"If you want to perform calculation on integer (press 1) or on float (press 2): "<<endl;
            cin>>choice_4;

            switch(choice_4)                         //Taking data type choice from user 
                {
                    case 1:                            //Option 1 for integer data
                        int a,b,ans;
                        cout<<"Enter 2 integers:";
                        cin>>a>>b;
                        break;        

                    case 2:                            //Option 2 for floating point data
                        double a,b,ans;
                        cout<<"Enter 2 floating point numbers:";
                        cin>>a>>b;
                        break;

                    default:
                        cout<<"Invalid choice";
                        break;
                }
            cout<<"Select an option from below: \n1.Addition \n2.Subtraction \n3.Multiplication \n4.Division";
            cin>>choice_5;

            switch(choice_5)                        //Performing calculations
            {
                case 1:
                    ans = a+b;
                    cout<<a<<" + "<<b<<" = "<<ans<<endl;
                    break;

                case 2:
                    ans = a-b;
                    cout<<a<<" - "<<b<<" = "<<ans<<endl;                    
                    break;

                case 3:
                    ans = a*b;
                    cout<<a<<" * "<<b<<" = "<<ans<<endl; 
                    break;

                case 4:
                    if (b==0)
                        cout<<"Can't be divided.";
                    else
                     {   ans = a/b;
                        cout<<a<<" / "<<b<<" = "<<ans<<endl;   }
                    break;
              
                default:
                    cout<<"Invalid Choice.";
                    break;
            }
            break;
        
        default:
            cout<<"Invalid Choice";
            break;
    }


    return 0;
}