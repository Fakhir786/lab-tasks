/*Task # 1 
Write a C++ program that uses if–else statements to check whether a given 
character entered by the user is a vowel or not a vowel. 
The program should take one character as input and display: 
• "is a vowel" if the entered character is a, e, i, o, or u (in either uppercase 
or lowercase), 
• otherwise, display "is not a vowel".*/

#include<iostream>
using namespace std;
int main()
{   cout<<"SAP_ID: 72990"<<endl<<"Name: Fakhir Ashar Chaudhry"<<endl;
    char ch;
    cout << "Enter a character: ";
    cin >> ch;

    if (ch == 'a' || ch == 'e' || ch == 'i' || ch == 'o' || ch == 'u' || ch == 'A' || ch == 'E' || ch == 'I' ||
         ch == 'O' || ch == 'U')

    {  cout << "\"" << ch << "\" is a vowel." << endl; }

    else
    { cout << "\"" << ch << "\" is not a vowel." << endl; }
    
    return 0;
}
