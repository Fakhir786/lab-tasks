#include<iostream>
#include<cmath>
using namespace std;
double a,b,ans;

int main()
{  
    int choice,choice_2,calc,integer,loop;
    cout<<"Sap_id: 72990"<<endl<<"Name: Fakhir Ashar Chaudhry"<<endl<<endl;
    do
    {
    cout<<"Select a choice: \n1.Scientific Calculator \n2.Simple Calculator"<<endl;
    cin>>choice;
    
    switch(choice)            //Calculator selection
    {
        case 1:
            calc=1;
            cout<<"Select an option from below:"<<endl<<"1.Sine \n2.Cosine \n3.Tangent  \n4.Square \n5.Cube \n6.Square Root"<<endl;
            cin>>choice_2;
            break;
        case 2:
            calc=2;
            cout<<"Select an option from below: \n1.Addition \n2.Subtraction \n3.Multiplication \n4.Division"<<endl;
            cin>>choice_2;
            break;
        default:
            cout<<"Invalid Choice"<<endl;
            break;
    }

    switch(calc)              //Taking input
    {
        case 1:
            cout<<"Enter a number:"<<endl;
            cin>>a;
            break;
        case 2:
            cout<<"Enter 2 numbers:"<<endl;
            cin>>a>>b;
            break;
        default:
            break;
    }
    
    if ((int(a)==a) && (int(b)==b))         //Typecasting
        {
            a=int(a);
            b=int(b);
            ans=int(ans);
        }

    if (choice==1)                          //Performing the calculation
    {
        switch(choice_2)
        {
            case 1:
                ans=sin(a);
                cout<<"The answer is:"<<ans<<endl;
                break;
            case 2:
                ans=cos(a);
                cout<<"The answer is:"<<ans<<endl;
                break;
            case 3:
                ans=tan(a);
                cout<<"The answer is:"<<ans<<endl;
                break;
            case 4:
                ans=pow(a,2);
                cout<<"The answer is:"<<ans<<endl;
                break;
            case 5:
                ans=pow(a,3);
                cout<<"The answer is:"<<ans<<endl;
                break;
            case 6:
                if (a<0)
                    cout<<"Square Root can't be calculated of negative numbers"<<endl;
                else
                { ans=sqrt(a);
                    cout<<"The answer is:"<<ans<<endl;}
                break;
            default:
                    cout<<"Invalid choice"<<endl;
                    break;
        }
    }
    else if (choice==2)
    {
        switch(choice_2)
        {
            case 1:
                ans=a+b;
                cout<<a<<" + "<<b<<" = "<<ans<<endl;
                break;
            case 2:
                ans=a-b;
                cout<<a<<" - "<<b<<" = "<<ans<<endl;
                break;
            case 3:
                ans=a*b;
                cout<<a<<" * "<<b<<" = "<<ans<<endl;
                break;
            case 4:
                if(b==0)
                    cout<<"Can't be divided by Zero"<<endl;
                else
                {ans=a/b;
                 cout<<a<<" / "<<b<<" = "<<ans<<endl;}
                break;
            default:
                cout<<"Invalid choice";
                break;
        }
    }
    
    

    cout<<"Select an option: \n1.Exit \n2.Continue"<<endl;
    cin>>loop;
    }
while(loop==2);

    cout<<"Calculator Closed!";
    return 0;

}