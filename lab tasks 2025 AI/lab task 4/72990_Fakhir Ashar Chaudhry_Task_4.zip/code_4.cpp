/* Task 4
2. Write a program that takes as input any number of seconds (as int) and then 
converts it in hours, minutes and seconds. For example, if you enter 7802 the 
program should print: 
2 hrs 10 mins 2 secs 
(Hint: Use integer division and modulus operators)*/
#include <iostream>
using namespace std;
int main()
{   
    cout<<"Sap_id: 72990"<<endl<<"Name: Fakhir Ashar"<<endl;
    int sec, hrs, min,t_sec;
    cout<<"Enter total seconds:";
    cin>>t_sec;
    hrs=t_sec/3600;
    t_sec=t_sec%3600;
    min=t_sec/60;
    sec=t_sec%60;
    cout<<t_sec<<"sec = "<<hrs<<"hrs "<<min<<"min "<<sec<<"sec";
    return 0;
}