/*Task # 2 
Write a C++ program that takes the temperature as input from the user and displays a message 
according to the following conditions: 
• If the temperature is greater than 35, display “It is a hot day.” 
• If the temperature is between 25 and 35 (inclusive), display “It is a pleasant day.” 
• If the temperature is less than 25, display “It is a cool day.” */

#include <iostream>
using namespace std;

int main()
{   cout<<"Sap_ID:72990"<<endl<<"Name: Fakhir Ashar Chaudhry"<<endl;
    
    float temperature;
    cout << "Enter the temperature: ";
    cin >> temperature;

    if (temperature > 35.0)
    {    cout << "It is a hot day." << endl; }

    else if ((temperature >= 25.0) && (temperature <= 35.0))
    {    cout << "It is a pleasant day." << endl;  }

    else
    {   cout << "It is a cool day." << endl;}

    return 0;}