/*Task 3 
Write a program that inputs grade of a student and display his test score on the 
following criteria: 
Test Score  Grade
>=    90      A
80 – 89       B
70 – 79       C
60 – 69       D
Below 60      F
*/   
#include <iostream>
using namespace std;    
int main()
{   
    cout<<"Sap_ID: 72990"<<endl<<"Name: Fakhir Ashar Chaudhry"<<endl;
    char grade;
    cout << "Enter the grade of the student: ";
    cin >> grade;
    
    switch(grade)
    {
        case 'A': case 'a':
            cout << "Test Score: >= 90" << endl;
            break;
        case 'B': case 'b':
            cout << "Test Score: 80 - 89" << endl;
            break;
        case 'C': case 'c':
            cout << "Test Score: 70 - 79" << endl;
            break;
        case 'D': case 'd':
            cout << "Test Score: 60 - 69" << endl;
            break;
        case 'F': case 'f':
            cout << "Test Score: Below 60" << endl;
            break;
        default:
            cout << "Invalid grade entered." << endl;
    }
}