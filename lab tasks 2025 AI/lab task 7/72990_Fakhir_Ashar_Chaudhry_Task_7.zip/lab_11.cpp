#include<iostream>
using namespace std;
int main()
{
    cout<<"Name: Fakhir Ashar CHaudhry"<<endl<<"Sap: 72990"<<endl;
    int arr[6];
    cout<<"Enter 6 numbers:"<<endl;
    cin>>arr[0]>>arr[1]>>arr[2]>>arr[3]>>arr[4]>>arr[5];
    cout<<"The entered numbers are:"<<endl<<arr[0]<<","<<arr[1]<<","<<arr[2]<<","<<arr[3]<<","<<arr[4]<<","<<arr[5]<<","<<endl;

    //using loop
    cout<<"Enter 6 numbers:"<<endl;
    for(int i=0;i<6;i++)
    {
        cin>>arr[i];
    }
    for(int i=0;i<6;i++)
    {
        cout<<arr[i]<<",";
    }
    return 0;
}