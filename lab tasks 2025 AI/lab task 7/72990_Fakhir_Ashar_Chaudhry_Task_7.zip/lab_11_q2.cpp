#include<iostream>
using namespace std;
int main()
{
    cout<<"Name: Fakhir Ashar CHaudhry"<<endl<<"Sap: 72990"<<endl;
    float arr[10],sum=0.0;
    cout<<"Enter marks of 10 students:"<<endl;
    for(int i=0;i<10;i++)
    {
        cin>>arr[i];
        sum=sum+arr[i];
    }
    cout<<"Average is:"<<sum/10.0;
    return 0;
}